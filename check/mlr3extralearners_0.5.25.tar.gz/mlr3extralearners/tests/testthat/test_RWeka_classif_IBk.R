install_learners("classif.IBk")

skip_on_os("windows")

test_that("autotest", {
  learner = LearnerClassifIBk$new()
  expect_learner(learner)
  result = run_autotest(learner)
  expect_true(result, info = result$error)
})
