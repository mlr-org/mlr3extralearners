bibentries = c( # nolint start
  breiman_2001 = bibentry("article",
    title       = "Random Forests",
    author      = "Breiman, Leo",
    year        = "2001",
    journal     = "Machine Learning",
    volume      = "45",
    number      = "1",
    pages       = "5--32",
    doi         = "10.1023/A:1010933404324",
    issn        = "1573-0565"
  ),

  ishwaran_2008 = bibentry("article",
    doi         = "10.1214/08-aoas169",
    url         = "https://doi.org/10.1214/08-aoas169",
    year        = "2008",
    month       = "9",
    publisher   = "Institute of Mathematical Statistics",
    volume      = "2",
    number      = "3",
    author      = "Hemant Ishwaran and Udaya B. Kogalur and Eugene H. Blackstone and Michael S. Lauer",
    title       = "Random survival forests",
    journal     = "The Annals of Applied Statistics"
  ),

  hothorn_2015 = bibentry("article",
    author      = "Torsten Hothorn and Achim Zeileis",
    title       = "partykit: A Modular Toolkit for Recursive Partytioning in R",
    journal     = "Journal of Machine Learning Research",
    year        = "2015",
    volume      = "16",
    number      = "118",
    pages       = "3905-3909",
    url         = "http://jmlr.org/papers/v16/hothorn15a.html"
  ),

  hothorn_2006 = bibentry("article",
    doi         = "10.1198/106186006x133933",
    url         = "https://doi.org/10.1198/106186006x133933",
    year        = "2006",
    month       = "9",
    publisher   = "Informa {UK} Limited",
    volume      = "15",
    number      = "3",
    pages       = "651--674",
    author      = "Torsten Hothorn and Kurt Hornik and Achim Zeileis",
    title       = "Unbiased Recursive Partitioning: A Conditional Inference Framework",
    journal     = "Journal of Computational and Graphical Statistics"
  ),

  jaeger_2019 = bibentry("article",
    doi           = "10.1214/19-aoas1261",
    year          = "2019",
    month         = "9",
    publisher     = "Institute of Mathematical Statistics",
    volume        = "13",
    number        = "3",
    author        = "Byron C. Jaeger and D. Leann Long and Dustin M. Long and Mario Sims and Jeff M. Szychowski and Yuan-I Min and Leslie A. Mcclure and George Howard and Noah Simon",
    title         = "Oblique random survival forests",
    journal       = "The Annals of Applied Statistics"
  ),

  dorogush2018catboost = bibentry("article",
    title = "CatBoost: gradient boosting with categorical features support",
    author = "Dorogush, Anna Veronika and Ershov, Vasily and Gulin, Andrey",
    journal = "arXiv preprint arXiv:1810.11363",
    year = "2018"
  ),

  binder2009boosting = bibentry("article",
    title = "Boosting for high-dimensional time-to-event data with competing risks",
    author = "Binder, Harald and Allignol, Arthur and Schumacher, Martin and Beyersmann, Jan",
    journal = "Bioinformatics",
    volume = "25",
    number = "7",
    pages = "890--896",
    year = "2009",
    publisher = "Oxford University Press"
  ),

  quinlan2014c4 = bibentry("book",
    title = "C4. 5: programs for machine learning",
    author = "Quinlan, J Ross",
    year = "2014",
    publisher = "Elsevier"
  ),

  quinlan1992learning = bibentry("inproceedings",
    title = "Learning with continuous classes",
    author = "Quinlan, John R and others",
    booktitle = "5th Australian joint conference on artificial intelligence",
    volume = "92",
    pages = "343--348",
    year = "1992",
    organization = "World Scientific"
  ),

  boltz2007knn = bibentry("inproceedings",
    title = "kNN-based high-dimensional Kullback-Leibler distance for tracking",
    author = "Boltz, Sylvain and Debreuve, Eric and Barlaud, Michel",
    booktitle = "Eighth International Workshop on Image Analysis for Multimedia Interactive Services (WIAMIS'07)",
    pages = "16--16",
    year = "2007",
    organization = "IEEE"
  ),

  sparapani2021nonparametric = bibentry("article",
    title = "Nonparametric machine learning and efficient computation with bayesian additive regression trees: the BART R package",
    author = "Sparapani, Rodney and Spanbauer, Charles and McCulloch, Robert",
    journal = "Journal of Statistical Software",
    volume = "97",
    pages = "1--66",
    year = "2021"
  ),


  quinlan1993combining = bibentry("inproceedings",
    title = "Combining instance-based and model-based learning",
    author = "Quinlan, J Ross",
    booktitle = "Proceedings of the tenth international conference on machine learning",
    pages = "236--243",
    year = "1993"
  ),

  milborrow2014earth = bibentry("article",
    title = "Earth: multivariate adaptive regression spline models",
    author = "Milborrow, Stephen and Hastie, T and Tibshirani, R",
    journal = "R package version",
    volume = "3",
    number = "7",
    year = "2014"
  ),
  friedman1991multivariate = bibentry("article",
    title = "Multivariate adaptive regression splines",
    author = "Friedman, Jerome H",
    journal = "The annals of statistics",
    volume = "19",
    number = "1",
    pages = "1--67",
    year = "1991",
    publisher = "Institute of Mathematical Statistics"
  ),
  geurts2006extremely = bibentry("article",
    title = "Extremely randomized trees",
    author = "Geurts, Pierre and Ernst, Damien and Wehenkel, Louis",
    journal = "Machine learning",
    volume = "63",
    number = "1",
    pages = "3--42",
    year = "2006",
    publisher = "Springer"
  ),
  royston2002flexible = bibentry("article",
    title = "Flexible parametric proportional-hazards and proportional-odds models for censored survival data, with application to prognostic modelling and estimation of treatment effects",
    author = "Royston, Patrick and Parmar, Mahesh KB",
    journal = "Statistics in medicine",
    volume = "21",
    number = "15",
    pages = "2175--2197",
    year = "2002",
    publisher = "Wiley Online Library"
  ),
  friedman2002stochastic = bibentry("article",
    title = "Stochastic gradient boosting",
    author = "Friedman, Jerome H",
    journal = "Computational statistics & data analysis",
    volume = "38",
    number = "4",
    pages = "367--378",
    year = "2002",
    publisher = "Elsevier"
  ),
  gu2003penalized = bibentry("article",
    title = "Penalized likelihood density estimation: Direct cross-validation and scalable approximation",
    author = "Gu, Chong and Wang, Jingyuan",
    journal = "Statistica Sinica",
    pages = "811--826",
    year = "2003",
    publisher = "JSTOR"
  ),
  quintela2012nonparametric = bibentry("article",
    title = "Nonparametric kernel distribution function estimation with kerdiest: an R package for bandwidth choice and applications",
    author = "Quintela-del-Río, Alejandro, and Graciela Estévez-Pérez",
    journal = "Journal of Statistical Software",
    volume = "50",
    pages = "1--21",
    year = "2012"
  ),
  karatzoglou2004kernlab = bibentry("article",
    title = "kernlab-an S4 package for kernel methods in R",
    author = "Karatzoglou, Alexandros and Smola, Alex and Hornik, Kurt and Zeileis, Achim",
    journal = "Journal of statistical software",
    volume = "11",
    number = "9",
    pages = "1--20",
    year = "2004",
    publisher = "American Statistical Association"
  ),
  gramacki2017fft = bibentry("article",
    title = "FFT-based fast computation of multivariate kernel density estimators with unconstrained bandwidth matrices",
    author = "Gramacki, Artur and Gramacki, Jarosław",
    journal = "Journal of Computational and Graphical Statistics",
    volume = "26",
    number = "2",
    pages = "459--462",
    year = "2017",
    publisher = "Taylor & Francis"
  ),
  fan2008liblinear = bibentry("article",
    title = "LIBLINEAR: A library for large linear classification",
    author = "Fan, Rong-En and Chang, Kai-Wei and Hsieh, Cho-Jui and Wang, Xiang-Rui and Lin, Chih-Jen",
    journal = "the Journal of machine Learning research",
    volume = "9",
    pages = "1871--1874",
    year = "2008",
    publisher = "JMLR. org"
  ),
  ke2017lightgbm = bibentry("article",
    title = "Lightgbm: A highly efficient gradient boosting decision tree",
    author = "Ke, Guolin and Meng, Qi and Finley, Thomas and Wang, Taifeng and Chen, Wei and Ma, Weidong and Ye, Qiwei and Liu, Tie-Yan",
    journal = "Advances in neural information processing systems",
    volume = "30",
    year = "2017"
  ),
  loader2006local = bibentry("book",
    title = "Local regression and likelihood",
    author = "Loader, Clive",
    year = "2006",
    publisher = "Springer Science & Business Media"
  ),
  kooperberg1992logspline = bibentry("article",
    title = "Logspline density estimation for censored data",
    author = "Kooperberg, Charles and Stone, Charles J",
    journal = "Journal of Computational and Graphical Statistics",
    volume = "1",
    number = "4",
    pages = "301--328",
    year = "1992",
    publisher = "Taylor & Francis"
  ),
  buhlmann2003boosting = bibentry("article",
    title = "Boosting with the L 2 loss: regression and classification",
    author = "Bühlmann, Peter and Yu, Bin",
    journal = "Journal of the American Statistical Association",
    volume = "98",
    number = "462",
    pages = "324--339",
    year = "2003",
    publisher = "Taylor & Francis"
  ),
  hastie2017generalized = bibentry("book",
    title = "Generalized additive models",
    author = "Hastie, Trevor J and Tibshirani, Robert J",
    year = "2017",
    publisher = "Routledge"
  ),
  wood2012mgcv = bibentry("misc",
    title = "mgcv: Mixed GAM Computation Vehicle with GCV/AIC/REML smoothness estimation",
    author = "Wood, Simon",
    year = "2012"
  ),
  li2003nonparametric = bibentry("article",
    title = "Nonparametric estimation of distributions with categorical and continuous data",
    author = "Li, Qi and Racine, Jeff",
    journal = "journal of multivariate analysis",
    volume = "86",
    number = "2",
    pages = "266--292",
    year = "2003",
    publisher = "Elsevier"
  ),
  goeman2010l1 = bibentry("article",
    title = "L1 penalized estimation in the Cox proportional hazards model",
    author = "Goeman, Jelle J",
    journal = "Biometrical journal",
    volume = "52",
    number = "1",
    pages = "70--84",
    year = "2010",
    publisher = "Wiley Online Library"
  ),
  schellhase2012density = bibentry("article",
    title = "Density estimation and comparison with a penalized mixture approach",
    author = "Schellhase, Christian and Kauermann, Göran",
    journal = "Computational Statistics",
    volume = "27",
    number = "4",
    pages = "757--777",
    year = "2012",
    publisher = "Springer"
  ),
  engel1994iterative = bibentry("article",
    title = "An iterative bandwidth selector for kernel estimation of densities and their derivatives",
    author = "Engel, Joachim and Herrmann, Eva and Gasser, Theo",
    journal = "Journaltitle of Nonparametric Statistics",
    volume = "4",
    number = "1",
    pages = "21--34",
    year = "1994",
    publisher = "Taylor & Francis"
  ),
  freund1996experiments = bibentry("inproceedings",
    title = "Experiments with a new boosting algorithm",
    author = "Freund, Yoav and Schapire, Robert E and others",
    booktitle = "icml",
    volume = "96",
    pages = "148--156",
    year = "1996",
    organization = "Citeseer"
  ),
  aha1991instance = bibentry("article",
    title = "Instance-based learning algorithms",
    author = "Aha, David W and Kibler, Dennis and Albert, Marc K",
    journal = "Machine learning",
    volume = "6",
    number = "1",
    pages = "37--66",
    year = "1991",
    publisher = "Springer"
  ),
  cohen1995fast = bibentry("incollection",
    title = "Fast effective rule induction",
    author = "Cohen, William W",
    booktitle = "Machine learning proceedings 1995",
    pages = "115--123",
    year = "1995",
    publisher = "Elsevier"
  ),
  landwehr2005logistic = bibentry("article",
    title = "Logistic model trees",
    author = "Landwehr, Niels and Hall, Mark and Frank, Eibe",
    journal = "Machine learning",
    volume = "59",
    number = "1",
    pages = "161--205",
    year = "2005",
    publisher = "Springer"
  ),
  holte1993very = bibentry("article",
    title = "Very simple classification rules perform well on most commonly used datasets",
    author = "Holte, Robert C",
    journal = "Machine learning",
    volume = "11",
    number = "1",
    pages = "63--90",
    year = "1993",
    publisher = "Springer"
  ),
  frank1998generating = bibentry("misc",
    title = "Generating accurate rule sets without global optimization",
    author = "Frank, Eibe and Witten, Ian H",
    year = "1998",
    publisher = "University of Waikato, Department of Computer Science"
  ),
  holmes1999generating = bibentry("inproceedings",
    title = "Generating rule sets from model trees",
    author = "Holmes, Geoffrey and Hall, Mark and Prank, Eibe",
    booktitle = "Australasian joint conference on artificial intelligence",
    pages = "1--12",
    year = "1999",
    organization = "Springer"
  ),
  bowman1997applied = bibentry("book",
    title = "Applied Smoothing Techniques for Data Analysis: The Kernel Approach with S-Plus Illustrations",
    author = "Bowman, A.W. and Azzalini, A.",
    isbn = "9780191545696",
    series = "Oxford Statistical Science Series",
    url = "https://books.google.de/books?id=7WBMrZ9umRYC",
    year = "1997",
    publisher = "OUP Oxford"
  ),
  hosmer2013applied = bibentry("book",
    title = "Applied logistic regression",
    author = "Hosmer Jr, David W and Lemeshow, Stanley and Sturdivant, Rodney X",
    volume = "398",
    year = "2013",
    publisher = "John Wiley & Sons"
  ),
  nelson1969hazard = bibentry("article",
    title = "Hazard plotting for incomplete failure data",
    author = "Nelson, Wayne",
    journal = "Journal of Quality Technology",
    volume = "1",
    number = "1",
    pages = "27--52",
    year = "1969",
    publisher = "Taylor & Francis"
  ),
  nelson1972theory = bibentry("article",
    title = "Theory and applications of hazard plotting for censored failure data",
    author = "Nelson, Wayne",
    journal = "Technometrics",
    volume = "14",
    number = "4",
    pages = "945--966",
    year = "1972",
    publisher = "Taylor & Francis"
  ),
  aalen1978nonparametric = bibentry("article",
    title = "Nonparametric inference for a family of counting processes",
    author = "Aalen, Odd",
    journal = "The Annals of Statistics",
    pages = "701--726",
    year = "1978",
    publisher = "JSTOR"
  ),
  kalbfleisch2011statistical = bibentry("book",
    title = "The statistical analysis of failure time data",
    author = "Kalbfleisch, John D and Prentice, Ross L",
    year = "2011",
    publisher = "John Wiley & Sons"
  ),
  akritas1994nearest = bibentry("article",
    title = "Nearest neighbor estimation of a bivariate distribution under random censoring",
    author = "Akritas, Michael G",
    journal = "The Annals of Statistics",
    pages = "1299--1327",
    year = "1994",
    publisher = "JSTOR"
  ),
  kvamme2019time = bibentry("article",
    title = "Time-to-event prediction with neural networks and Cox regression",
    author = "Kvamme, Håvard, Ørnulf Borgan, and Ida Scheel",
    journal = "arXiv preprint arXiv:1907.00825",
    year = "2019"
  ),
  lee2018deephit = bibentry("inproceedings",
    title = "Deephit: A deep learning approach to survival analysis with competing risks",
    author = "Lee, Changhee and Zame, William and Yoon, Jinsung and Van Der Schaar, Mihaela",
    booktitle = "Proceedings of the AAAI conference on artificial intelligence",
    volume = "32",
    number = "1",
    year = "2018"
  ),
  katzman2018deepsurv = bibentry("article",
    title = "DeepSurv: personalized treatment recommender system using a Cox proportional hazards deep neural network",
    author = "Katzman, Jared L and Shaham, Uri and Cloninger, Alexander and Bates, Jonathan and Jiang, Tingting and Kluger, Yuval",
    journal = "BMC medical research methodology",
    volume = "18",
    number = "1",
    pages = "1--12",
    year = "2018",
    publisher = "BioMed Central"
  ),
  zhao2019dnnsurv = bibentry("article",
    title = "Dnnsurv: Deep neural networks for survival analysis using pseudo values",
    author = "Zhao, Lili and Feng, Dai",
    journal = "arXiv preprint arXiv:1908.02337",
    year = "2019"
  ),
  gensheimer2018simple = bibentry("article",
    title = "Simple discrete-time survival model for neural networks",
    author = "Gensheimer, Michael F and Narasimhan, BA",
    journal = "arXiv",
    year = "2018"
  ),
  kvamme2019continuous = bibentry("article",
    title = "Continuous and discrete-time survival prediction with neural networks",
    author = "Kvamme, Håvard, and Ørnulf Borgan",
    journal = "arXiv preprint arXiv:1910.06724",
    year = "2019"
  ),
  van2011improved = bibentry("article",
    title = "Improved performance on high-dimensional survival data by application of Survival-SVM",
    author = "Van Belle, Vanya and Pelckmans, Kristiaan and Van Huffel, Sabine and Suykens, Johan AK",
    journal = "Bioinformatics",
    volume = "27",
    number = "1",
    pages = "87--94",
    year = "2011",
    publisher = "Oxford University Press"
  ),

  van2011support = bibentry("article",
    title = "Support vector methods for survival analysis: a comparison between ranking and regression approaches",
    author = "Van Belle, Vanya and Pelckmans, Kristiaan and Van Huffel, Sabine and Suykens, Johan AK",
    journal = "Artificial intelligence in medicine",
    volume = "53",
    number = "2",
    pages = "107--118",
    year = "2011",
    publisher = "Elsevier"
  ),
  shivaswamy2007support = bibentry("inproceedings",
    title = "A support vector approach to censored targets",
    author = "Shivaswamy, Pannagadatta K and Chu, Wei and Jansche, Martin",
    booktitle = "Seventh IEEE international conference on data mining (ICDM 2007)",
    pages = "655--660",
    year = "2007",
    organization = "IEEE"
  )








































) # nolint end) # nolint end
